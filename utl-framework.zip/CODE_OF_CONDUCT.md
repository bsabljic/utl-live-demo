# Code of Conduct

Ovaj projekt poštuje principe inkluzivnosti i poštovanja. Očekuje se da svi sudionici:
- komuniciraju s poštovanjem
- izbjegavaju uvredljiv sadržaj
- prihvate povratne informacije u dobroj namjeri

Kršenje pravila može rezultirati upozorenjem ili uklanjanjem doprinosa.

Temeljeno na Contributor Covenant (https://www.contributor-covenant.org/).